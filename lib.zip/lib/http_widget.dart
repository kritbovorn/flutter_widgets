import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

class HttpWidget extends StatelessWidget {
  const HttpWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rest API Tutorial'),
      ),
      body: Container(),
    );
  }
}
