import 'package:flutter/material.dart';
import 'package:flutter_project/services/api_service.dart';
import 'package:flutter_project/widgets/bottom_content_widget.dart';
import 'package:flutter_project/widgets/code_content_widget.dart';
import 'package:flutter_project/widgets/form_field_content_widget.dart';
import 'package:flutter_svg/svg.dart';

class LogInScreen extends StatefulWidget {
  const LogInScreen({Key? key}) : super(key: key);

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  TextEditingController userControl = TextEditingController();
  TextEditingController passwordControl = TextEditingController();
  String username = '';
  String password = '';
  // CircularProgressIndicator
  bool isLoading = false;

  sendData() {
    setState(() {
      isLoading = true;
      ApiService().login(context, username, password).then((value) => {
            setState(() => {
                  isLoading = false,
                  username = '',
                  password = '',
                  userControl.clear(),
                  passwordControl.clear(),
                  FocusScope.of(context).unfocus(),
                }),
          });
    });
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: screenSize.width,
        height: screenSize.height,
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/bg.png'), fit: BoxFit.fitHeight),
        ),
        child: Stack(
          children: [
            SafeArea(
              bottom: false,
              child: Column(
                children: [
                  Expanded(
                    child: SizedBox(
                        child: SvgPicture.asset("assets/ico-true-plus.svg")),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: FormFieldContentWidget(
                      userController: userControl,
                      passwordController: passwordControl,
                      onChangeUser: (value) => {
                        setState(() => username = value),
                      },
                      onChangePassword: (value) => {
                        setState(() => password = value),
                      },
                      onPressed: sendData,
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 28),
                    child: CodeContentWidget(),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: const BottomContentWidget(),
                  ),
                ],
              ),
            ),
            isLoading
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Colors.black.withOpacity(0.8),
                    child: const Center(
                      child: CircularProgressIndicator(
                        color: Colors.white,
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }
}
