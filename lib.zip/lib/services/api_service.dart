import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_project/screens/home_screen.dart';
import 'package:http/http.dart' as http;

class ApiService {
  Future<void> login(
      BuildContext context, String username, String password) async {
    if (username.isNotEmpty && password.isNotEmpty) {
      try {
        http.Response response = await http.post(
            Uri.parse("https://fakestoreapi.com/auth/login"),
            body: ({"username": username, "password": password}));
        if (response.statusCode == 200) {
          var data = await jsonDecode(response.body.toString());
          var token = data["token"];

          SchedulerBinding.instance.addPostFrameCallback(
            (timeStamp) {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomeScreen(token: token),
                  ));
            },
          );
        } else {
          SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content:
                    Text("รหัสสมาชิก หรือ รหัสผ่าน ไม่ถูกต้องนะค่ะ 🥺🥺🥺")));
          });
        }
      } catch (e) {
        SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text(
                  "เกิดข้อผิดพลาดทางระบบสื่อสาร รบกวนลองใหม่อีกครั้ง นะค่ะ")));
        });
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('คุณกรอกรายละเอียด มาไม่ครบ นะค่ะ'),
        ),
      );
    }
  }
}
